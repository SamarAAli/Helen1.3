package com.example.tarek_ragaeey.helen11;

import org.json.JSONObject;

public interface FragmentListener {
    public void setDetailsData(JSONObject Movieobj);
}
